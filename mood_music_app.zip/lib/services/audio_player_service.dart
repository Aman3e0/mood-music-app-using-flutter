import 'package:audioplayers/audioplayers.dart';

class AudioPlayerService {
  final AudioPlayer _player = AudioPlayer();

  Future<void> play(String url) async {
    await _player.play(UrlSource(url));
  }

  void pause() => _player.pause();
  void stop() => _player.stop();
}
