import 'package:flutter/material.dart';
import '../models/song.dart';
import '../services/audio_player_service.dart';

class SongTile extends StatelessWidget {
  final Song song;
  final AudioPlayerService playerService = AudioPlayerService();

  SongTile({super.key, required this.song});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(song.title),
      subtitle: Text(song.artist),
      trailing: IconButton(
        icon: const Icon(Icons.play_arrow),
        onPressed: () => playerService.play(song.url),
      ),
    );
  }
}
