import 'package:flutter/material.dart';
import '../models/song.dart';
import 'dart:convert';
import 'package:flutter/services.dart';

class MoodProvider extends ChangeNotifier {
  String _currentMood = '';
  List<Song> _songs = [];

  String get currentMood => _currentMood;
  List<Song> get songs => _songs;

  Future<void> setMood(String mood) async {
    _currentMood = mood;
    await loadSongs();
    notifyListeners();
  }

  Future<void> loadSongs() async {
    final String response = await rootBundle.loadString('lib/data/songs.json');
    final data = json.decode(response);
    _songs = (data[_currentMood] as List).map((e) => Song.fromJson(e)).toList();
  }
}
