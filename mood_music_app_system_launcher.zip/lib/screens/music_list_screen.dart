import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/mood_provider.dart';
import '../widgets/song_tile.dart';

class MusicListScreen extends StatelessWidget {
  const MusicListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<MoodProvider>(context);

    return Scaffold(
      appBar: AppBar(title: Text('\${provider.currentMood} Songs')),
      body: ListView.builder(
        itemCount: provider.songs.length,
        itemBuilder: (context, index) {
          return SongTile(song: provider.songs[index]);
        },
      ),
    );
  }
}
