import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/mood_provider.dart';
import '../screens/music_list_screen.dart';

class MoodSelector extends StatelessWidget {
  const MoodSelector({super.key});

  final List<String> moods = const ['Happy', 'Sad', 'Energetic', 'Calm'];

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.all(20),
      itemCount: moods.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2, childAspectRatio: 1.2, crossAxisSpacing: 10, mainAxisSpacing: 10,
      ),
      itemBuilder: (context, index) {
        return ElevatedButton(
          onPressed: () async {
            final mood = moods[index];
            await Provider.of<MoodProvider>(context, listen: false).setMood(mood);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const MusicListScreen()),
            );
          },
          child: Text(mood),
        );
      },
    );
  }
}
